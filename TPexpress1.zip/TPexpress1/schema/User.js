const mongoose = require('mongoose');

let userSchema = mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    firstName: String,
    lastName: String
}, {
    timestamps: true
});
userSchema.method.fullName = function () {
    return `${this.firstName}${this.lastName}`;
};
exports.userSchema = userSchema


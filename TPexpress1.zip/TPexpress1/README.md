# NodeJS sample base project

This is the first step of our little project.

const mongoose = require('mongoose');
let userSchema = require('../schema/User');


userModel = mongoose.model('User', userSchema);
console.log(userModel);
var veronica = new userModel({ firstName: 'Veronica', lastName: 'RedField', email: "redfield@labboratory" });
veronica.save(function (err) {
  if (err) return handleError(err);
  // saved!
});

areYouThere = userModel.find({ firstname: 'Veronica' });
result = areYouThere.exec(function (err, docs) {});
console.log(result); 
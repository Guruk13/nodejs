const mongoose = require('mongoose');
let  dbUrl = 'mongodb://admin:password@localhost:27017/admin';
//connection mongoose 
mongoose.connect(dbUrl,
  (error) => {
    if (error) throw error;
    });
